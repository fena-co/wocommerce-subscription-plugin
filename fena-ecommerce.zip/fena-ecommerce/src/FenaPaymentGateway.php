<?php

namespace FenaCommerceGateway;

use WC_Payment_Gateway;

final class FenaPaymentGateway extends WC_Payment_Gateway
{
    private $terminal_id;
    private $terminal_secret;

    public function __construct()
    {

        $this->id = 'fena_payment';
        $this->method_title = 'Fena';

        $this->method_description = "Fast instant bank to bank payments";  // to backend
        $this->order_button_text = 'Proceed to pay';

        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');

        $this->has_fields = false;

        // only support products
        $this->supports = array(
            'products'
        );

        $this->countries = ['GB'];

        $this->init_form_fields();
        $this->init_settings();

        // Check if subscriptions are enabled and add support for them.
		$this->maybe_init_subscriptions();

        $this->enabled = $this->get_option('enabled');
        $this->terminal_id = $this->get_option('terminal_id');
        $this->terminal_secret = $this->get_option('terminal_secret');
        
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

        add_action('woocommerce_api_fena', array($this, 'webhook'));
    }
	
    public function maybe_init_subscriptions()
    {

        $this->supports = array(
            'subscriptions',
            'subscription_cancellation',
            'subscription_suspension',
            'subscription_reactivation',
            'subscription_amount_changes',
            'subscription_date_changes',
            'subscription_payment_method_change',
            'subscription_payment_method_change_customer',
            'subscription_payment_method_change_admin',
            'multiple_subscriptions',
        );
    }  
    public function process_subscription_payment( $order_id ) {
        return PaymentSubscription::process($order_id, $this->terminal_id, $this->terminal_secret);
    }
    public function init_form_fields()
    {
        $this->form_fields = AdminPortalOptions::get();
    }

    function admin_options()
    {
		
		self::checkDataApi($this->terminal_secret,$this->terminal_id);
		
        AdminPortalUI::get($this->generate_settings_html([], false));
    }
	
	public function checkDataApi($terminal_secret, $terminal_id)
	{	
	
 
		$urlGet = 'https://business.api.staging.fena.co/public/common/bank-account/connection-type';

        $responseGet = wp_remote_get( $urlGet, array(
            'headers' => array(
                'Accept' => 'application/json',
                'integration-id' => $terminal_id,
                'secret-key' => $terminal_secret
            )
        ) );
        
        // check if you got the right answer
        //if ( is_wp_error( $responseGet ) ){
          //  echo $responseGet->get_error_message();
        //}
        //else
			if( wp_remote_retrieve_response_code( $responseGet ) === 200 ){
            // All OK, do something with the data $request['body']
            $body = wp_remote_retrieve_body( $responseGet );
            $result = json_decode($body);
			$result = (array) $result;
			$result = (array)($result['data']);
            if($result['connectionType']=='manually_created'){
				echo '<div class="updated notice">
                      <p>';
					  _e( "For Recurring payment you have to update the status manually.");
				echo '</p>
                      </div>';
					  
				 //\WC_Admin_Settings::add_message('For Recurring payment you have to update the status manually.');
				

			}  
        }	  
	
	}
	
    public function process_admin_options()
    {
        parent::process_admin_options();
        return AdminPortalOptions::validate($this->terminal_secret, $this->terminal_id);
    }

    public function process_payment($order_id)
    {
        //$product = wc_get_order( $order_id );

        if ( function_exists( 'wcs_order_contains_subscription' ) && ( wcs_order_contains_subscription( $order_id ) || wcs_is_subscription( $order_id ) || wcs_order_contains_renewal( $order_id ) ) ) {
            return PaymentSubscription::process($order_id, $this->terminal_id, $this->terminal_secret);
        }else{
            return PaymentProcess::process($order_id, $this->terminal_id, $this->terminal_secret);
        }
        
    }

    public function get_icon()
    {
        return CheckoutIcon::get($this->id);
    }

    public function webhook()
    {
        PaymentNotification::process($this->terminal_id, $this->terminal_secret);
    }
}

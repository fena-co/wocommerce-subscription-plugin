<?php

namespace FenaCommerceGateway;
global $woocommerce;
class PaymentSubscription
{
 

    public static function process($order_id, $terminal_id, $terminal_secret)
    {

        $order = new \WC_Order($order_id);

        $order_number = $order->get_order_number();

        $subscriptions =  wcs_get_subscriptions_for_order( $order_id, array('order_type' => 'parent') );

        foreach( $subscriptions as $subscription_id => $subscription ) {
            // Get Subscription Details
            $renewal_total += $subscription->get_total();
            $period = $subscription->get_billing_period();
                    // Get Subscription Length

            $targetDate = $subscription->get_date('end');
            
            if($targetDate){
            $currentTimestamp = time();

            // Convert the target date to a timestamp
            $targetTimestamp = strtotime($targetDate);
            
            // Calculate the difference in seconds
            $secondsDiff = $targetTimestamp - $currentTimestamp;
            
            // Calculate the number of weeks
            $weeks = ceil($secondsDiff / (60 * 60 * 24 * 7));
            
            // Calculate the number of months
            $currentDate = date('Y-m-d', $currentTimestamp);
            $currentMonth = date('m', $currentTimestamp);
            $currentYear = date('Y', $currentTimestamp);
            
            $targetMonth = date('m', $targetTimestamp);
            $targetYear = date('Y', $targetTimestamp);
            
            $months = (($targetYear - $currentYear) * 12) + ($targetMonth - $currentMonth);
            
            // Calculate the number of years
            $years = floor($months / 12);
            }
        
        }
    
        if($period == 'month'){
            $frequency = 'one_month';
            $frequencyNext = '+1 months';
            $expire = $months;
        }if($period == 'week'){
            $frequency = 'one_week';
            $frequencyNext = '+1 week';
            $expire = $weeks;
        }if($period == 'year'){
            $frequency = 'one_year';
            $frequencyNext = '+1 year';
            $expire = $years;
        }
        if($expire){
            $expireSub = (int)$expire + 1;
        }else{
            $expireSub = 0;
        }
      
        $currentDate = date('Y-m-d\TH:i:s\Z');
        $nDate = date( 'Y-m-d',strtotime( $frequencyNext, strtotime( $currentDate ) ) );
        // Set the start date and number of days to check
        $arra = file_get_contents("https://www.gov.uk/bank-holidays.json");
        $ars = json_decode($arra);
        $array = (array) $ars;
        
        $bank_holidays = array();
        foreach($array['england-and-wales']->events as $key){
          $bank_holidays[] = $key->date;
          
        } 

        $weekend = array('Saturday', 'Sunday');

        $timestamp = strtotime($nDate);
        
        while (true) {
            $dayOfWeek = date('l', $timestamp);
            
            // Check if the date falls on a weekend
            if (in_array($dayOfWeek, $weekend)) {
            $timestamp = strtotime('+1 day', $timestamp);
            continue;
            }
            
            // Check if the date falls on a bank holiday
            if (in_array(date('Y-m-d', $timestamp), $bank_holidays)) {
            $timestamp = strtotime('+1 day', $timestamp);
            continue;
            }
            
            // A valid date has been found
            break;
        }
        
        // Return the adjusted date
        $nxtPayDate = date('Y-m-d', $timestamp);
        $total = str_replace(',', '', number_format($renewal_total, 2, '.', ''));
        $name = $order->get_billing_first_name().' '.$order->get_billing_last_name();
        $date = date('Y-m-d\TH:i:s\Z',  strtotime( $nxtPayDate ) ); 
        //echo $date;
        $data = array(
            "reference" => $order_number,
            "recurringAmount"=> $total,
            "recurringPaymentDate"=>$date,
            "numberOfPayments"=> $expireSub,
            "frequency"=> $frequency,
            "initialPaymentAmount"=> $order->get_total(),
            "customerName"=> $name,
            "customerEmail"=> $order->get_billing_email()   
        );
      
        $dataJson = json_encode($data);

		$url = 'https://business.api.staging.fena.co/public/recurring-payments/create-and-process';

        $response = wp_remote_post($url, array(
		
          'headers'     => array('Content-Type' => 'application/json; charset=utf-8','integration-id' => $terminal_id,
          'secret-key' => $terminal_secret),
  
          'body'        => $dataJson,
  
          'method'      => 'POST',
  
          'data_format' => 'body',
  
        ));
        
        $resultData = json_decode($response['body'], true);
     
        $url =  $resultData['result']['link'];

            $order->update_status('awaiting_payment', 'Awaiting payment');
            $order->add_meta_data( '_fena_payment_url', $url );
            $order->add_meta_data( '_fena_payment_date', $currentDate );
            $order->save_meta_data();
            return array(
                'result' => 'success',
                'redirect' => $url
            );
    
    }

}
<?php
/*
Plugin Name:       Fena ECommerce
Plugin URI:        https://github.com/fena-co/fena-woocommerce-gateway
Description:       Enables the Fena payment option on woocommerce.
Version:           1.1.3
Author:            Fena
Author URI:        https://www.fena.co
Text Domain:       fena

Fena ECommerce Plugin is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
any later version.

Fena ECommerce Plugin is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Fena ECommerce Plugin. If not, see https://www.gnu.org/licenses/gpl-3.0.html.
*/
//  auto load
if (!file_exists(plugin_dir_path(__FILE__) . 'vendor/autoload.php')) {
    die;
}
require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';


function fena_woocommerce_stripe_missing_wc_notice()
{
    echo '<div class="error"><p><strong>Fena requires WooCommerce to be installed and active. You can download <a href="https://woocommerce.com/" target="_blank">WooCommerce</a> from here.</strong></p></div>';
}


function woocommerce_gateway_fena_init()
{
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'fena_woocommerce_stripe_missing_wc_notice');
        return;
    }

    add_filter('woocommerce_payment_gateways', 'addFenaPaymentGateway');
    function addFenaPaymentGateway($gateways)
    {
        $gateways[] = 'FenaCommerceGateway\\FenaPaymentGateway';
        return $gateways;
    }

    require plugin_dir_path(__FILE__) . "src/FenaPaymentGateway.php";
}


add_action('plugins_loaded', 'woocommerce_gateway_fena_init');


add_filter('woocommerce_available_payment_gateways', 'conditional_payment_gateways', 10, 1);
function conditional_payment_gateways( $available_gateways ) {
    // Not in backend (admin)
    if( is_admin() ) 
        return $available_gateways;

	$subsArray = [];
	$freqArray = [];
	$i = 0;
    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
        $prod_variable = $prod_simple = $prod_subscription = false;
		
        // Get the WC_Product object
        $product = wc_get_product($cart_item['product_id']);
        // Get the product types in cart (example)
        if($product->is_type('simple')) $prod_simple = true;
        if($product->is_type('variable')) $prod_variable = true;
        if($product->is_type('subscription')) { 
			$prod_subscription = true;
			$subsArray[] = $i;			
		}
	
		$subscription_period = WC_Subscriptions_Product::get_period( $product );
        $subscription_interval = WC_Subscriptions_Product::get_interval( $product );

		if($subscription_period == 'day' || $subscription_interval > 1){
            $freqArray[] = $i;	   
		}	
      

		$i++;
    }
	$arraylenth = count($subsArray);
	if($arraylenth > 1){
		unset($available_gateways['fena_payment']); 
	}
	if(!empty($freqArray)){
        unset($available_gateways['fena_payment']);
	}

    return $available_gateways;
}




